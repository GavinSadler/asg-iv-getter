function IVgetterMat2Xls(Summary,folder,filename)

e = actxserver('Excel.Application');
eWorkbook = e.Workbooks.Add;
eSheets = e.ActiveWorkbook.Sheets;
eSheets.Item(1).Name='Raw Data';
CurrentSheet=eSheets.get('Item','Raw Data');
CurrentSheet.Activate;


Wafers=fieldnames(Summary);

Column=1;%65=A

ActiveRange=get(e.Activesheet,'Range',[ProperRange(Column),'1:',ProperRange(Column),'6']);
ActiveRange.Value={'Wafer';'Chip';'Step';'Illumination';'Comments';'Units'};
Column=Column+1;

for ii=1:length(Wafers)
    Chips=fieldnames(Summary.(Wafers{ii}));
    for jj=1:length(Chips)
        Steps=fieldnames(Summary.(Wafers{ii}).(Chips{jj}));
        for kk=1:length(Steps)
            Illumination=fieldnames(Summary.(Wafers{ii}).(Chips{jj}).(Steps{kk}));
            for ll=1:length(Illumination)
                for mm=1:length(Summary.(Wafers{ii}).(Chips{jj}).(Steps{kk}).(Illumination{ll}).Comments)
                    ActiveRange=get(e.Activesheet,'Range',[ProperRange(Column),'1:',ProperRange(Column+1),num2str(6)]);
                    ActiveRange.Value=[repmat({Wafers{ii};Chips{jj};Steps{kk};Illumination{ll};Summary.(Wafers{ii}).(Chips{jj}).(Steps{kk}).(Illumination{ll}).Comments{mm}},1,2);{'Voltage (V)' 'Current (A)'}];
                    ActiveRange=get(e.Activesheet,'Range',[ProperRange(Column),'7:',ProperRange(Column+1),num2str(6+length(Summary.(Wafers{ii}).(Chips{jj}).(Steps{kk}).(Illumination{ll}).Voltage(:,mm)))]);
                    ActiveRange.Value=[Summary.(Wafers{ii}).(Chips{jj}).(Steps{kk}).(Illumination{ll}).Voltage(:,mm) Summary.(Wafers{ii}).(Chips{jj}).(Steps{kk}).(Illumination{ll}).Current(:,mm)];
                    Column=Column+2;
                end
            end
        end
    end
end

SaveAs(eWorkbook,[folder,'\',filename,'_RawData.xlsx'])
eWorkbook.Saved = 1;
Close(eWorkbook)
end